import { HomecloudConsole } from "@/components/homecloud-console"

export default function HomePage() {
  return <HomecloudConsole />
}
